import finnhub
import datetime
import time

finnhub_client = finnhub.Client(api_key="cfj73ghr01que34nr220cfj73ghr01que34nr22g")

start_time = datetime.datetime(2023, 2, 5, 0, 0)
end_time = datetime.datetime(2023, 2, 10, 0, 0)

# print regular python date&time
print("date_time =>", start_time)

# displaying unix timestamp after conversion
print("unix_timestamp => ",
      (time.mktime(start_time.timetuple())))
print("unix_timestamp => ",
      (time.mktime(end_time.timetuple())))
#1678999042

res = finnhub_client.stock_candles('AMD', '1', 1677703042, 1678999042)['c']
print(res)

#print(finnhub_client.quote("AMD"))
#print(finnhub_client.company_news('AMD', _from="2023-02-09", to="2023-02-10"))


